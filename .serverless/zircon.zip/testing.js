'use strict';
const zircon = require('./handler');

function debug(err,data){
  if (err) {
    console.error(err);
  }
  else {
    console.log(data);
  }
}

zircon.apiLookup({path:'/some/thing'},{},debug);
zircon.apiLookup({path:'/some/gist'},{},debug);
zircon.popLookup({path:'/some/aws-tue'},{},debug);
