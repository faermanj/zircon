A quick and dirty URL shortener for personal use, such as books, articles and publications.

How to use:

1. Set your links in data.js
2. Install http://serverless.com
3. $ sls deploy
4. profit!
